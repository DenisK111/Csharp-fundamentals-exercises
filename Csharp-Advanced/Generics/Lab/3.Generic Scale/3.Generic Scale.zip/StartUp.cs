﻿using System;

namespace GenericScale
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            Console.WriteLine(new EqualityScale<int>(4,4).AreEqual()); 
        }
    }
}
