﻿namespace DirectoryTraversal
{
    internal class Dictionary
    {
    }
}