﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage
{
    public interface IAgeable 
    {
        
        public int Age { get; set; }
    }
}
