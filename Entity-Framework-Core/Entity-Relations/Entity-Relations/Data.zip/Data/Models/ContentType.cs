﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entity_Relations.Data.Models
{
    public enum ContentType
    {
       
            Application = 10,
            Pdf = 20,
            Zip = 30,
        
    }
}
