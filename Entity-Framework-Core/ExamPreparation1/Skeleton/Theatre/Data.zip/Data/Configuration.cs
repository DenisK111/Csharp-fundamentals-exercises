﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=localhost,1433;Initial Catalog=Theatre;User ID=sa;Password=Sql12345678";
    }
}
