﻿namespace CarDealer.DTO
{
    public class ExportPartDto
    {
        public string Name { get; set; }
        public string Price { get; set; }
    }
}