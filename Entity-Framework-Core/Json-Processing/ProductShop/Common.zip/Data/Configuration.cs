﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=localhost,1433;Database=ProductShop;User ID=sa;Password=Sql12345678";
    }
}
