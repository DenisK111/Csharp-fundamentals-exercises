﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=localhost,1433;Initial Catalog = MusicHub; User ID = sa; Password=Sql12345678";
    }
}
